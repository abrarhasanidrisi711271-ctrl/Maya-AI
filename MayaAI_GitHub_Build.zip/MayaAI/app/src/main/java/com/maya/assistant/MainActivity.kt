package com.maya.assistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import androidx.core.app.ActivityCompat
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var transcript: TextView
    private lateinit var status: TextView
    private lateinit var input: EditText
    private lateinit var tts: TextToSpeech
    private var speechRecognizer: SpeechRecognizer? = null
    private val history = JSONArray()

    // Configure these only if you have a trusted HTTPS backend.
    // Do NOT put a provider API key directly in this Android app.
    private val assistantEndpoint = "" // Example: https://your-server.example/chat

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        buildUi()
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
        }
    }

    private fun buildUi() {
        val bg = Color.rgb(16, 20, 38)
        val panel = Color.rgb(29, 35, 59)
        val white = Color.WHITE
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 28, 22, 18)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "Maya"
            textSize = 32f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "Your personal AI voice assistant"
            textSize = 14f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
        }
        status = TextView(this).apply {
            text = "Offline backup ready"
            textSize = 13f
            setTextColor(Color.rgb(150, 220, 180))
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 12)
        }
        transcript = TextView(this).apply {
            text = "Hi! I'm Maya. Tap the microphone or type a message."
            textSize = 17f
            setTextColor(white)
            setPadding(16, 18, 16, 18)
            background = rounded(panel, 18)
            gravity = Gravity.CENTER_VERTICAL
        }
        val scroll = ScrollView(this).apply {
            addView(transcript)
        }
        input = EditText(this).apply {
            hint = "Type to Maya..."
            setHintTextColor(Color.LTGRAY)
            setTextColor(white)
            textSize = 16f
            setSingleLine(true)
            setPadding(14, 12, 14, 12)
            background = rounded(panel, 14)
        }
        val send = Button(this).apply {
            text = "Send"
            setOnClickListener {
                val msg = input.text.toString().trim()
                if (msg.isNotEmpty()) { input.setText(""); handleMessage(msg) }
            }
        }
        val mic = Button(this).apply {
            text = "🎙  Speak"
            setOnClickListener { startListening() }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(input, LinearLayout.LayoutParams(0, -2, 1f))
            addView(send)
        }
        val quick = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            addView(Button(this@MainActivity).apply {
                text = "Set alarm"
                setOnClickListener { handleMessage("Set an alarm for 7:00 AM") }
            })
            addView(Button(this@MainActivity).apply {
                text = "Open browser"
                setOnClickListener { openBrowser() }
            })
        }
        root.addView(title)
        root.addView(subtitle)
        root.addView(status)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(mic)
        root.addView(row)
        root.addView(quick)
        setContentView(root)
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
    }

    private fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            reply("Speech recognition isn't available on this phone right now.")
            return
        }
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 10)
            return
        }
        try {
            if (speechRecognizer == null) speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
            speechRecognizer?.setRecognitionListener(object : android.speech.RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { status.text = "Listening..." }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() { status.text = "Thinking..." }
                override fun onError(error: Int) { status.text = "Ready"; }
                override fun onResults(results: Bundle?) {
                    val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    words?.firstOrNull()?.let { handleMessage(it) }
                    status.text = "Ready"
                }
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            }
            speechRecognizer?.startListening(intent)
        } catch (_: Exception) {
            reply("I couldn't start the microphone. Check microphone permission.")
        }
    }

    private fun handleMessage(message: String) {
        transcript.text = "You: $message\n\nMaya is thinking..."
        history.put(JSONObject().put("role", "user").put("content", message))
        if (tryOfflineAction(message)) return
        if (assistantEndpoint.isNotBlank()) {
            askOnline(message)
        } else {
            reply("I'm using my offline backup. I can help with basic phone actions, but online AI isn't connected yet. Add a secure HTTPS backend endpoint in MainActivity.kt to enable the online brain.")
        }
    }

    private fun tryOfflineAction(message: String): Boolean {
        val m = message.lowercase(Locale.ROOT)
        if (m.contains("open browser") || m.contains("internet kholo") || m.contains("browser kholo")) {
            openBrowser()
            reply("Opening your browser.")
            return true
        }
        if (m.contains("open settings") || m.contains("settings kholo")) {
            startActivity(Intent(android.provider.Settings.ACTION_SETTINGS))
            reply("Opening phone settings.")
            return true
        }
        if (m.contains("alarm") || m.contains("अलार्म")) {
            val time = Regex("(\\d{1,2})[:.](\\d{2})").find(message)
            if (time != null) {
                val hour = time.groupValues[1].toIntOrNull() ?: 7
                val minute = time.groupValues[2].toIntOrNull() ?: 0
                val i = Intent(android.provider.AlarmClock.ACTION_SET_ALARM).apply {
                    putExtra(android.provider.AlarmClock.EXTRA_HOUR, hour.coerceIn(0, 23))
                    putExtra(android.provider.AlarmClock.EXTRA_MINUTES, minute.coerceIn(0, 59))
                    putExtra(android.provider.AlarmClock.EXTRA_MESSAGE, "Maya reminder")
                    putExtra(android.provider.AlarmClock.EXTRA_SKIP_UI, false)
                }
                if (i.resolveActivity(packageManager) != null) startActivity(i)
                reply("I've opened the clock app to set the alarm for $hour:${minute.toString().padStart(2, '0')}. Please confirm it there.")
            } else {
                reply("Tell me the time, for example: set an alarm for 7:30.")
            }
            return true
        }
        if (m.contains("time") || m.contains("समय") || m.contains("kitne baje")) {
            val now = java.text.SimpleDateFormat("hh:mm a", Locale.getDefault()).format(java.util.Date())
            reply("The time is $now.")
            return true
        }
        if (m.contains("hello") || m.contains("hi") || m.contains("नमस्ते") || m.contains("हेलो")) {
            reply("Hello! Main Maya hoon. Batao, main kya karoon?")
            return true
        }
        return false
    }

    private fun openBrowser() {
        val i = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com"))
        startActivity(i)
    }

    private fun askOnline(message: String) {
        status.text = "Online AI..."
        thread {
            var answer = "Online AI couldn't be reached. Offline backup is ready."
            try {
                val conn = (URL(assistantEndpoint).openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 12000
                    readTimeout = 20000
                    doOutput = true
                    setRequestProperty("Content-Type", "application/json")
                }
                val body = JSONObject().put("message", message).put("history", history).toString()
                conn.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
                val stream = if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader().use { it.readText() }
                if (conn.responseCode in 200..299) {
                    answer = JSONObject(response).optString("reply", answer)
                }
                conn.disconnect()
            } catch (_: Exception) {}
            runOnUiThread { reply(answer) }
        }
    }

    private fun reply(text: String) {
        transcript.text = "Maya: $text"
        history.put(JSONObject().put("role", "assistant").put("content", text))
        status.text = if (assistantEndpoint.isBlank()) "Offline backup mode" else "Ready"
        if (::tts.isInitialized) tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "maya_reply")
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            val result = tts.setLanguage(Locale("hi", "IN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts.language = Locale.US
            }
            tts.setSpeechRate(0.96f)
            tts.setPitch(1.08f)
        }
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        if (::tts.isInitialized) tts.shutdown()
        super.onDestroy()
    }
}
