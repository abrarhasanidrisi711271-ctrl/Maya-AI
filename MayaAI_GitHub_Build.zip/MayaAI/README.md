# Maya AI Assistant (Android starter)

A Kotlin Android Studio starter for a Hindi/English voice assistant with:
- Android speech recognition for voice input
- Android Text-to-Speech for spoken replies (female-sounding pitch; exact voice depends on the phone's installed TTS voice)
- Offline starter commands: greeting, current time, open Settings, open browser, and opening the Clock app to confirm an alarm
- Optional online AI connection through a secure HTTPS backend

## Open the project
1. Install Android Studio.
2. Choose **Open** and select this `MayaAI` folder.
3. Let Gradle sync finish.
4. Connect your Android phone with USB debugging enabled, or use an emulator.
5. Press Run.

## Permissions
The app asks for microphone permission. Internet permission is declared. It does not request contacts, SMS, call-log, or accessibility permissions.

## Connect an online AI safely
The app expects your own HTTPS backend to accept:
```json
{"message":"Hello Maya","history":[{"role":"user","content":"Hello Maya"}]}
```
and return:
```json
{"reply":"Hello! How can I help?"}
```
Set `assistantEndpoint` in `MainActivity.kt` to your backend URL.

**Important:** Do not put OpenRouter, Gemini, OpenAI, or other provider API keys directly in an APK. APKs can be inspected and keys extracted. Keep provider keys on your server and let the app call your server. Use HTTPS only.

## Current limitations
- This is a starter project, not a finished production assistant.
- Offline mode is rule-based and does not contain a full offline language model.
- Alarm creation opens the Clock confirmation screen; the user must confirm it.
- Speech recognition availability and language support depend on Android and installed recognition services.
- Female voice selection depends on the phone's installed Hindi/English TTS voices. Android TTS settings can be used to install/change voices.
- The online backend is intentionally not included; it must be deployed separately.
- The project source is provided, but it has not been built or tested on a physical device in this environment.

## Next development steps
1. Add a secure backend for an OpenAI-compatible model provider.
2. Add streaming voice conversation.
3. Add local reminders with explicit confirmation and notification permission.
4. Add app-launch shortcuts through safe Android intents.
5. Add an in-app language and voice selector.
